#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve, auc
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.metrics import roc_auc_score, f1_score, roc_curve, auc
import matplotlib.pyplot as plt


# In[2]:


#นำเข้าข้อมูล
data = pd.read_csv('sanitary.csv')


# In[3]:


data


# In[4]:


data.info()


# In[5]:


data = data.drop(columns=['location'])


# In[6]:


# สร้าง Bar Chart สำหรับ brand
plt.figure(figsize=(10, 6))
sns.countplot(x='brand', data=data)
plt.title('Distribution of Brands')
plt.xlabel('Brand')
plt.ylabel('Count')
plt.show()


# In[7]:


# พล็อต Histogram ของคอลัมน์ 'price'
plt.figure(figsize=(10, 6))
sns.histplot(data['price'], kde=True)
plt.title('Histogram of price')
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.show()


# In[8]:


# พล็อต Histogram ของคอลัมน์ 'sale'
plt.figure(figsize=(10, 6))
sns.histplot(data['sale'], kde=True)
plt.title('Histogram of sale')
plt.xlabel('Sale')
plt.ylabel('Frequency')
plt.show()


# In[9]:


# พล็อต Histogram ของคอลัมน์ 'total_sale'
plt.figure(figsize=(10, 6))
sns.histplot(data['total_sale'], kde=True)
plt.title('Histogram of total_sale')
plt.xlabel('Total Sale')
plt.ylabel('Frequency')
plt.show()


# In[10]:


# สร้าง Pie chart สำหรับ 'usage'
usage_counts = data['usage'].value_counts()

plt.figure(figsize=(8, 8))
plt.pie(usage_counts, labels=usage_counts.index, autopct='%1.1f%%', startangle=90)
plt.title('Pie chart for Usage')
plt.show()


# In[11]:


# สร้าง Pie chart สำหรับ 'usage'
usage_counts = data['type'].value_counts()

plt.figure(figsize=(8, 8))
plt.pie(usage_counts, labels=usage_counts.index, autopct='%1.1f%%', startangle=40)
plt.title('Pie chart for Type')
plt.show()


# In[12]:


# สร้าง Pie chart สำหรับ 'wing'
wing_counts = data['wing'].value_counts()

# Plotting a pie chart
plt.figure(figsize=(8, 8))
plt.pie(wing_counts, labels=wing_counts.index, autopct='%1.1f%%', startangle=90)
plt.title('Pie chart for Wing')
plt.show()


# In[13]:


# สร้าง Pie chart สำหรับ 'size'
wing_counts = data['size'].value_counts()

# Plotting a pie chart
plt.figure(figsize=(8, 8))
plt.pie(wing_counts, labels=wing_counts.index, autopct='%1.1f%%', startangle=90)
plt.title('Pie chart for Size')
plt.show()


# In[14]:


# สร้าง Bar chart สำหรับ 'performance'
plt.figure(figsize=(8, 6))
sns.countplot(x='performance', data=data)
plt.title('Bar chart for Performance')
plt.show()


# In[15]:


#เตรียมข้อมูลและแบ่งชุดข้อมูล
x = data.drop(['total_sale'], axis=1)
y = data['total_sale']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)


# In[16]:


categorical_features = ["brand","wing","type","size","usage"]
one_hot = OneHotEncoder()
transformer = ColumnTransformer([("one_hot",one_hot,categorical_features)],remainder="passthrough")

transformed_x = transformer.fit_transform(x)
transformed_x


# In[17]:


pd.DataFrame(transformed_x)


# In[24]:


#แก้ไข missing values
imputer = SimpleImputer(strategy='mean')  
data = imputer.fit_transform(transformed_x)


# In[26]:


# สร้างข้อมูลสำหรับทดสอบ
x, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)

# แบ่งข้อมูลเป็นชุดฝึกและชุดทดสอบ
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

# สร้างและฝึกโมเดล (Random Forest Classifier)
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(x_train, y_train)

# สร้างและฝึกโมเดล (CatBoost Classifier)
catboost_model = CatBoostClassifier(iterations=100, random_state=42, verbose=0)
catboost_model.fit(x_train, y_train)

# สร้างและฝึกโมเดล (LightGBM Classifier)
lgbm_model = LGBMClassifier(n_estimators=100, random_state=42)
lgbm_model.fit(x_train, y_train)

# สร้างและฝึกโมเดล (XGBoost Classifier)
xgb_model = XGBClassifier(n_estimators=100, random_state=42)
xgb_model.fit(x_train, y_train) 


# In[27]:


# ทำนายความน่าจะเป็นในคลาส positive สำหรับทุกรุ่น
rf_predictions = rf_model.predict(x_test)
catboost_predictions = catboost_model.predict(x_test)
lgbm_predictions = lgbm_model.predict(x_test)
xgb_predictions = xgb_model.predict(x_test)

# ประเมินโมเดลแต่ละตัว
rf_accuracy = accuracy_score(y_test, rf_predictions)
catboost_accuracy = accuracy_score(y_test, catboost_predictions)
lgbm_accuracy = accuracy_score(y_test, lgbm_predictions)
xgb_accuracy = accuracy_score(y_test, xgb_predictions)

print(f'Random Forest Accuracy: {rf_accuracy:.2f}')
print(f'CatBoost Accuracy: {catboost_accuracy:.2f}')
print(f'LightGBM Accuracy: {lgbm_accuracy:.2f}')
print(f'XGBoost Accuracy: {xgb_accuracy:.2f}')


# In[28]:


# สร้าง VotingClassifier
voting_clf = VotingClassifier(estimators=[
    ('random_forest', rf_model),
    ('catboost', catboost_model),
    ('lgbm', lgbm_model),
    ('xgb', xgb_model)
], voting='soft')  


# In[29]:


# ทำ VotingClassifier จากแบบจำลองทั้งหมด
voting_clf.fit(x_train, y_train)


# In[30]:


# ใช้ VotingClassifier ในการทำนายข้อมูลทดสอบ (หลังจากที่ฝึกไว้แล้ว)
predictions = voting_clf.predict(x_test)

# ประเมินประสิทธิภาพของโมเดลบนข้อมูลทดสอบ
accuracy = accuracy_score(y_test, predictions)
conf_matrix = confusion_matrix(y_test, predictions)
class_report = classification_report(y_test, predictions)

print(f'Accuracy: {accuracy:.2f}')
print(f'Confusion Matrix:\n{conf_matrix}')
print(f'Classification Report:\n{class_report}')


# In[31]:


# ทำนายความน่าจะเป็นในคลาส positive สำหรับ VotingClassifier
voting_probabilities = voting_clf.predict_proba(x_test)[:, 1]

# คำนวณ ROC curve และ AUC
fpr, tpr, thresholds = roc_curve(y_test, voting_probabilities)
roc_auc = auc(fpr, tpr)

# วาด ROC curve
plt.figure(figsize=(8, 8))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'VotingClassifier (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend(loc='lower right')
plt.show()


# In[ ]:




